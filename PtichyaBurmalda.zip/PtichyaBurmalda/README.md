# Птичья бурмалда — Android

1. Установите Android Studio (https://developer.android.com/studio).
2. File → Open → выберите эту папку, дождитесь Gradle Sync.
3. Run — запуск на телефоне или эмуляторе.
4. APK: Build → Build Bundle(s)/APK(s) → Build APK(s).

Игра лежит в app/src/main/assets/index.html.

## Сборка без Android Studio (GitHub Actions)
1. Создайте репозиторий на github.com и загрузите в него содержимое этой папки (включая скрытую папку .github).
2. Откройте вкладку Actions → Build APK → дождитесь зелёной галочки (2–4 мин).
3. В конце запуска скачайте артефакт PtichyaBurmalda-debug-apk, внутри будет app-debug.apk.
4. Перенесите APK на телефон и установите (разрешите установку из неизвестных источников).
